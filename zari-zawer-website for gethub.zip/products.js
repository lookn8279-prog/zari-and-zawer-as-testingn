/**
 * Zari & Zawer - Luxury E-Commerce Product Catalog
 * Prices in PKR (Pakistani Rupee)
 */

const PRODUCTS_DATA = [
  // --- DRESSES ---
  {
    id: "dr-01",
    name: "Noor-e-Zill Velvet Peshwas",
    category: "dresses",
    categoryLabel: "Festive Couture",
    price: 78500,
    originalPrice: 88000,
    rating: 4.9,
    reviewsCount: 38,
    isNew: true,
    isBestSeller: true,
    sku: "ZZ-DR-2026-01",
    primaryImage: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1609357605129-26f69add5d6e?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Deep maroon micro-velvet kalidaar peshwas enriched with hand-embroidered dabka, marori, and zardozi tilla craftsmanship.",
    description: "The Noor-e-Zill Peshwas represents timeless subcontinent royalty. Sculpted from rich plush micro-velvet in imperial deep maroon, it is hand-embellished across the bodice, kalis, and border with intricate dabka, kora, tilla, and lustrous pearls. Paired with a crushed tissue silk lehenga and a heavily bordered sheer organza dupatta featuring hand-cut scallops.",
    fabric: "Pure Micro-Velvet & Tissue Organza",
    color: "Deep Maroon",
    colorHex: "#5B121C",
    occasion: "Bridal & Formal",
    sizes: ["XS", "S", "M", "L", "XL", "Custom"],
    inStock: true
  },
  {
    id: "dr-02",
    name: "Shehnai Crimson Bridal Lehanga",
    category: "dresses",
    categoryLabel: "Bridal Masterpiece",
    price: 245000,
    originalPrice: 265000,
    rating: 5.0,
    reviewsCount: 22,
    isNew: true,
    isBestSeller: true,
    sku: "ZZ-DR-2026-02",
    primaryImage: "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Pure crimson raw silk bridal lehanga adorned with traditional naqshi, mukesh, and Swarovski crystal clusters.",
    description: "An heirloom piece designed for the modern bride who treasures heritage. Cut on pure 80-gram raw silk in classic bridal crimson, featuring a 24-kali flared skirt covered in traditional architectural jaal work, paired with a fitted hand-crafted choli and twin dupattas (one heavy velvet veil and one light tissue sheer).",
    fabric: "Pure Raw Silk, Velvet & Handloom Net",
    color: "Crimson Red",
    colorHex: "#8B1425",
    occasion: "Bridal",
    sizes: ["S", "M", "L", "Custom"],
    inStock: true
  },
  {
    id: "dr-03",
    name: "Gul-e-Rana Emerald Anarkali",
    category: "dresses",
    categoryLabel: "Festive Pret",
    price: 64000,
    originalPrice: 72000,
    rating: 4.8,
    reviewsCount: 19,
    isNew: false,
    isBestSeller: true,
    sku: "ZZ-DR-2026-03",
    primaryImage: "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Emerald green hand-spun tissue organza with delicate gold gota kinari and French-knot floral resham motifs.",
    description: "A dreamy silhouette glowing in jewel-toned emerald. The flowing anarkali is detailed with antique gold tilla laces, delicate gota patti rosettes, and an embroidered waistband. Finished with silk churidar trousers and a gold tissue dupatta edged with handmade latkans.",
    fabric: "Tissue Organza & Pure Silk",
    color: "Emerald Green",
    colorHex: "#114B3A",
    occasion: "Festive & Party",
    sizes: ["XS", "S", "M", "L", "XL"],
    inStock: true
  },
  {
    id: "dr-04",
    name: "Mehtab Ivory Chiffon Sharara Set",
    category: "dresses",
    categoryLabel: "Luxury Pret",
    price: 52000,
    originalPrice: 58000,
    rating: 4.9,
    reviewsCount: 45,
    isNew: true,
    isBestSeller: false,
    sku: "ZZ-DR-2026-04",
    primaryImage: "https://images.unsplash.com/photo-1518049362265-d5b2a6467637?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1518049362265-d5b2a6467637?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Pristine ivory pure crinkle chiffon with subtle champagne gold zardozi, sequins, and pearl sprigs.",
    description: "Subtle elegance personified. The short kurti features an intricate keyhole neckline embellished with champagne cutdana, framed by double-tiered voluminous sharara pants with scalloped hems. Accompanied by a lightweight mukaish dupatta.",
    fabric: "100% Crinkle Chiffon & Silk Lining",
    color: "Ivory Gold",
    colorHex: "#F7F3E8",
    occasion: "Nikkah & Reception",
    sizes: ["XS", "S", "M", "L"],
    inStock: true
  },
  {
    id: "dr-05",
    name: "Firoza Jamawar Royal Angrakha",
    category: "dresses",
    categoryLabel: "Festive Couture",
    price: 68000,
    originalPrice: 75000,
    rating: 4.7,
    reviewsCount: 16,
    isNew: false,
    isBestSeller: false,
    sku: "ZZ-DR-2026-05",
    primaryImage: "https://images.unsplash.com/photo-1566737236500-c8ac43014a67?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1566737236500-c8ac43014a67?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Hand-spun turquoise and gold metallic jamawar angrakha with jeweled tassel ties and zardozi cuffs.",
    description: "An homage to Mughal royal courts. Crafted in metallic turquoise jamawar, the overlapping angrakha bodice secures with handcrafted jeweled crystal doris. Pair with cigarette pants or a straight culotte for effortless poise.",
    fabric: "Pure Banarsi Jamawar & Organza",
    color: "Turquoise Gold",
    colorHex: "#1B7B82",
    occasion: "Festive",
    sizes: ["S", "M", "L", "XL"],
    inStock: true
  },

  // --- JEWELRY ---
  {
    id: "jw-01",
    name: "Nizam-i-Kundan Choker & Jhumka Set",
    category: "jewelry",
    categoryLabel: "Heirloom Jewelry",
    price: 48000,
    originalPrice: 55000,
    rating: 5.0,
    reviewsCount: 64,
    isNew: true,
    isBestSeller: true,
    sku: "ZZ-JW-2026-01",
    primaryImage: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "22k gold micro-plated Jadau Kundan choker with natural emerald drops and cascading pearl jhumkas.",
    description: "Handcrafted by master karigars using centuries-old Jadau settings. Features uncut glass kundan stones backed with silver foil for ethereal radiance, accented with Colombian emerald glass beads and natural freshwater seed pearls. The reverse showcases intricate Persian Meenakari enamel art.",
    fabric: "22K Gold Plated Brass, Kundan, Pearls & Meenakari",
    color: "Gold & Emerald",
    colorHex: "#C5A059",
    occasion: "Bridal & Wedding",
    sizes: ["Adjustable Dori"],
    inStock: true
  },
  {
    id: "jw-02",
    name: "Maharani Polki Chandbali Earrings",
    category: "jewelry",
    categoryLabel: "Earrings",
    price: 26500,
    originalPrice: 30000,
    rating: 4.9,
    reviewsCount: 51,
    isNew: false,
    isBestSeller: true,
    sku: "ZZ-JW-2026-02",
    primaryImage: "https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1601121141461-9d6647bca1ed?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Dramatic crescent chandbalis framed with uncut polki crystals, ruby beads, and tiny pearl drops.",
    description: "Celebrate classic subcontinent glamour with these statement crescent moon earrings. Meticulously set with mirror polki gems, finished with a crown of rubellite stones and rhythmic pearl fringe. Lightweight comfort backs ensure all-evening wear.",
    fabric: "Antique Gold Plated Brass & Faux Polki",
    color: "Champagne Gold & Ruby",
    colorHex: "#9B2226",
    occasion: "Festive & Party",
    sizes: ["Standard Drop (9cm)"],
    inStock: true
  },
  {
    id: "jw-03",
    name: "Noor Jehan Pearl & Tilla Mathapatti",
    category: "jewelry",
    categoryLabel: "Bridal Ornaments",
    price: 18900,
    originalPrice: 22000,
    rating: 4.8,
    reviewsCount: 29,
    isNew: true,
    isBestSeller: false,
    sku: "ZZ-JW-2026-03",
    primaryImage: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Regal single-tier head ornament woven with cultured seed pearls and floral kundan pendants.",
    description: "Frame your bridal visage with timeless grace. The Noor Jehan Mathapatti features seven tiers of delicate seed pearls anchoring a central floral tikka medallion studded with sparkling kundan and finished with a tear-drop emerald.",
    fabric: "24K Gold Polish, Cultured Pearls, Kundan",
    color: "Pearl Ivory & Gold",
    colorHex: "#EAE0D5",
    occasion: "Bridal",
    sizes: ["One Size Fits All"],
    inStock: true
  },
  {
    id: "jw-04",
    name: "Shahzadi Emerald Guluband",
    category: "jewelry",
    categoryLabel: "Collar Necklaces",
    price: 39500,
    originalPrice: 44000,
    rating: 4.9,
    reviewsCount: 33,
    isNew: false,
    isBestSeller: true,
    sku: "ZZ-JW-2026-04",
    primaryImage: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Royal choker collar encrusted with simulated Colombian emeralds and brilliant-cut CZ stones.",
    description: "An imperial choker necklace designed to hug the neckline gracefully. Crafted with precision-cut emerald cubic zirconia stones bordered by micro-pave zirconia crystals in an antique rhodium-and-gold two-tone finish.",
    fabric: "High Grade Brass, AAA+ Cubic Zirconia",
    color: "Deep Emerald & Gold",
    colorHex: "#1B4332",
    occasion: "Formal & Reception",
    sizes: ["Adjustable Clasp"],
    inStock: true
  },
  {
    id: "jw-05",
    name: "Zafira Filigree Bangles (Set of 2)",
    category: "jewelry",
    categoryLabel: "Kadas & Bangles",
    price: 22000,
    originalPrice: 26000,
    rating: 4.8,
    reviewsCount: 42,
    isNew: false,
    isBestSeller: false,
    sku: "ZZ-JW-2026-05",
    primaryImage: "https://images.unsplash.com/photo-1611591475805-59b4865c3bb8?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1611591475805-59b4865c3bb8?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Hand-carved floral vine openable kadas with screw lock mechanism and ruby highlights.",
    description: "Classic subcontinent artistry meets modern wearable luxury. These statement openable bangles feature intricate jaali filigree openwork, embellished with fine kundan studs and bezel-set ruby stones.",
    fabric: "Hallmark Finish Brass, Kundan Stones",
    color: "Gold & Ruby",
    colorHex: "#D4AF37",
    occasion: "Festive & Wedding",
    sizes: ["2.4", "2.6", "2.8"],
    inStock: true
  },

  // --- CLUTCHES ---
  {
    id: "cl-01",
    name: "The Celestial Bird Crystal Minaudière",
    category: "clutches",
    categoryLabel: "Couture Minaudière",
    price: 34500,
    originalPrice: 39000,
    rating: 5.0,
    reviewsCount: 88,
    isNew: true,
    isBestSeller: true,
    hasVideo: true,
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-glittering-golden-dust-floating-in-the-air-41484-large.mp4",
    sku: "ZZ-CL-2026-01",
    primaryImage: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Showstopper sculpted bird cage clutch encrusted with over 1,400 Austrian crystals and detachable gold snake chain.",
    description: "The crown jewel of Zari & Zawer accessories. Meticulously shaped into a majestic songbird resting upon an ornate golden perch, this minaudière is paved entirely by hand with multi-faceted Austrian crystals that catch light from every angle. Features a hidden push-lock clasp, luxurious velvet interior lining, and an optional 100cm champagne gold chain.",
    fabric: "Polished Metal Alloy, Austrian Crystals & Velvet Lining",
    color: "Champagne Gold Crystal",
    colorHex: "#DFB15B",
    occasion: "Bridal, Red Carpet, Formal",
    sizes: ["Compact Minaudière (18 x 12 x 7 cm)"],
    inStock: true
  },
  {
    id: "cl-02",
    name: "Shahi Maroon Velvet Zardozi Potli",
    category: "clutches",
    categoryLabel: "Artisanal Potli",
    price: 16500,
    originalPrice: 19500,
    rating: 4.9,
    reviewsCount: 72,
    isNew: false,
    isBestSeller: true,
    sku: "ZZ-CL-2026-02",
    primaryImage: "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=1200&q=85",
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Rich crimson velvet potli adorned with antique copper dabka, pearl latkans, and braided gold handle.",
    description: "A cherished wedding staple. Crafted in royal maroon Italian velvet, featuring handcrafted floral motifs in antique copper tilla and resham. Finished with dramatic cascading pearl and zari tassels that dance as you move.",
    fabric: "Italian Velvet & Seed Pearls",
    color: "Deep Maroon",
    colorHex: "#540B0E",
    occasion: "Wedding & Mehndi",
    sizes: ["Standard Potli (22 x 20 cm)"],
    inStock: true
  },
  {
    id: "cl-03",
    name: "Aura Mother-of-Pearl Hardcase Clutch",
    category: "clutches",
    categoryLabel: "Shell Minaudière",
    price: 28000,
    originalPrice: 32000,
    rating: 4.8,
    reviewsCount: 35,
    isNew: true,
    isBestSeller: false,
    sku: "ZZ-CL-2026-03",
    primaryImage: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Hand-cut iridescent mother-of-pearl geometric mosaic with brass rim and magnetic cabochon clasp.",
    description: "An heirloom statement clutch crafted with authentic hand-cut sea shell tiles inlaid into a geometric pattern. The mother-of-pearl exhibits natural opalescent sheen, framed in brush-finished 18K gold brass.",
    fabric: "Natural Mother of Pearl Shell & Brass",
    color: "Opalescent Pearl",
    colorHex: "#F0ECE1",
    occasion: "Reception & Evening Gala",
    sizes: ["Box Clutch (20 x 11 x 5 cm)"],
    inStock: true
  },
  {
    id: "cl-04",
    name: "Jashn Emerald Embroidered Box Clutch",
    category: "clutches",
    categoryLabel: "Evening Clutch",
    price: 19500,
    originalPrice: 23000,
    rating: 4.9,
    reviewsCount: 41,
    isNew: false,
    isBestSeller: false,
    sku: "ZZ-CL-2026-04",
    primaryImage: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Emerald green silk satin clutch heavily hand-embroidered with cutdana, sequins, and a crystal top-knob.",
    description: "Indulge in jewel-toned luxury. This compact structured clutch is wrapped in emerald raw silk and decorated with geometric metallic sequin embroidery. Opens with an exquisite emerald-cut crystal jewel lock.",
    fabric: "Raw Silk, Glass Beads & Gold Hardware",
    color: "Emerald Green",
    colorHex: "#0D3B2E",
    occasion: "Festive & Dinner",
    sizes: ["19 x 10 x 4 cm"],
    inStock: true
  },
  {
    id: "cl-05",
    name: "Gohar Pearl Embellished Minaudière",
    category: "clutches",
    categoryLabel: "Pearl Minaudière",
    price: 24000,
    originalPrice: 28000,
    rating: 4.8,
    reviewsCount: 26,
    isNew: true,
    isBestSeller: false,
    sku: "ZZ-CL-2026-05",
    primaryImage: "https://images.unsplash.com/photo-1575032617751-6ddec2089882?auto=format&fit=crop&w=900&q=80",
    secondaryImage: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=900&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1575032617751-6ddec2089882?auto=format&fit=crop&w=1200&q=85"
    ],
    shortDesc: "Cascading rows of lustrous faux pearls hand-stitched over champagne gold metallic leatherette.",
    description: "Elegance woven into every bead. The Gohar clutch dazzles with dense rows of graduated pearls and a bejeweled ring-handle clasp that allows it to be carried like fine jewelry.",
    fabric: "Champagne Leatherette & Cultured Pearls",
    color: "Champagne Pearl",
    colorHex: "#EFE5CE",
    occasion: "Nikkah & Reception",
    sizes: ["18 x 12 x 5 cm"],
    inStock: true
  }
];

// Testimonials data
const TESTIMONIALS_DATA = [
  {
    name: "Ayesha Jahangir",
    city: "Lahore",
    comment: "The Shehnai Crimson Bridal Lehanga exceeded all my wedding dreams! The intricate dabka and crystal work caught every spotlight. The bespoke stitching service was flawless.",
    rating: 5,
    tag: "Verified Bridal Bride"
  },
  {
    name: "Mahnoor Tariq",
    city: "Karachi",
    comment: "I ordered The Celestial Bird Crystal Minaudière for my sister's valima in London. It arrived in Karachi within 48 hours, beautifully boxed. Everyone kept asking where I got it!",
    rating: 5,
    tag: "Verified Buyer"
  },
  {
    name: "Dr. Fatima Al-Zahra",
    city: "Islamabad",
    comment: "The Nizam-i-Kundan set has the weight and meenakari finish of genuine heirloom gold jewelry. Truly royal subcontinent craftsmanship at its finest.",
    rating: 5,
    tag: "Jewelry Collector"
  }
];

// Export to window
if (typeof window !== "undefined") {
  window.PRODUCTS_DATA = PRODUCTS_DATA;
  window.TESTIMONIALS_DATA = TESTIMONIALS_DATA;
}
