/**
 * Zari & Zawer - Luxury E-Commerce Web Application Logic
 */

(function () {
  "use strict";

  // Application State
  const state = {
    cart: JSON.parse(localStorage.getItem("zz_cart") || "[]"),
    wishlist: JSON.parse(localStorage.getItem("zz_wishlist") || "[]"),
    activeCategory: "all",
    searchQuery: "",
    sortBy: "featured",
    filterOccasion: "all",
    filterPriceMax: 300000,
    promoCode: null,
    promoDiscount: 0,
    activeProduct: null
  };

  // Helper: Format Currency in PKR
  function formatPKR(amount) {
    return "PKR " + Number(amount).toLocaleString("en-PK");
  }

  // Toast Notifications
  function showToast(title, message = "", type = "success") {
    let container = document.getElementById("toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "toast-container";
      document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = "toast-item";
    
    const icon = type === "wishlist" 
      ? '<i class="fa-solid fa-heart text-[#c5a059] text-lg"></i>' 
      : '<i class="fa-solid fa-gem text-[#c5a059] text-lg"></i>';

    toast.innerHTML = `
      <div class="flex items-center space-x-3">
        ${icon}
        <div>
          <h5 class="text-sm font-semibold tracking-wide text-white">${title}</h5>
          ${message ? `<p class="text-xs text-gray-300 mt-0.5">${message}</p>` : ""}
        </div>
      </div>
      <button class="text-gray-400 hover:text-white text-xs ml-3 focus:outline-none">&times;</button>
    `;

    toast.querySelector("button").addEventListener("click", () => {
      toast.classList.remove("show");
      setTimeout(() => toast.remove(), 350);
    });

    container.appendChild(toast);
    setTimeout(() => toast.classList.add("show"), 20);

    setTimeout(() => {
      if (toast.parentElement) {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 350);
      }
    }, 4000);
  }

  // Save State
  function saveCart() {
    localStorage.setItem("zz_cart", JSON.stringify(state.cart));
    updateCounters();
    renderCartDrawer();
  }

  function saveWishlist() {
    localStorage.setItem("zz_wishlist", JSON.stringify(state.wishlist));
    updateCounters();
    updateWishlistBadges();
  }

  // Update Badge Counters
  function updateCounters() {
    const totalCartCount = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartBadges = document.querySelectorAll(".cart-counter-badge");
    cartBadges.forEach(badge => {
      badge.textContent = totalCartCount;
      badge.classList.toggle("hidden", totalCartCount === 0);
    });

    const totalWishCount = state.wishlist.length;
    const wishBadges = document.querySelectorAll(".wishlist-counter-badge");
    wishBadges.forEach(badge => {
      badge.textContent = totalWishCount;
      badge.classList.toggle("hidden", totalWishCount === 0);
    });
  }

  // Wishlist Toggle
  window.toggleWishlist = function (productId) {
    const index = state.wishlist.indexOf(productId);
    const product = window.PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    if (index > -1) {
      state.wishlist.splice(index, 1);
      showToast("Removed from Wishlist", product.name, "wishlist");
    } else {
      state.wishlist.push(productId);
      showToast("Saved to Wishlist", product.name, "wishlist");
    }
    saveWishlist();
  };

  function updateWishlistBadges() {
    document.querySelectorAll("[data-wishlist-btn]").forEach(btn => {
      const pId = btn.getAttribute("data-wishlist-btn");
      const icon = btn.querySelector("i");
      if (state.wishlist.includes(pId)) {
        icon.className = "fa-solid fa-heart text-[#c5a059]";
        btn.setAttribute("title", "Remove from Wishlist");
      } else {
        icon.className = "fa-regular fa-heart text-gray-600 hover:text-[#c5a059]";
        btn.setAttribute("title", "Add to Wishlist");
      }
    });
  }

  // Add to Cart
  window.addToCart = function (productId, size = null, color = null, qty = 1, showDrawer = true) {
    const product = window.PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    const chosenSize = size || (product.sizes ? product.sizes[0] : "Standard");
    const chosenColor = color || product.color;

    const existingIndex = state.cart.findIndex(
      item => item.id === productId && item.size === chosenSize && item.color === chosenColor
    );

    if (existingIndex > -1) {
      state.cart[existingIndex].quantity += qty;
    } else {
      state.cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.primaryImage,
        category: product.category,
        size: chosenSize,
        color: chosenColor,
        quantity: qty
      });
    }

    saveCart();
    showToast("Added to Shopping Bag", `${qty}x ${product.name} (${chosenSize})`);

    if (showDrawer) {
      openCartDrawer();
    }
  };

  // Cart Drawer open/close
  window.openCartDrawer = function () {
    const drawerBackdrop = document.getElementById("cart-drawer-backdrop");
    const drawerPanel = document.getElementById("cart-drawer-panel");
    if (!drawerBackdrop || !drawerPanel) return;

    drawerBackdrop.classList.add("active");
    drawerPanel.classList.add("active");
    document.body.style.overflow = "hidden";
    renderCartDrawer();
  };

  window.closeCartDrawer = function () {
    const drawerBackdrop = document.getElementById("cart-drawer-backdrop");
    const drawerPanel = document.getElementById("cart-drawer-panel");
    if (!drawerBackdrop || !drawerPanel) return;

    drawerBackdrop.classList.remove("active");
    drawerPanel.classList.remove("active");
    document.body.style.overflow = "";
  };

  // Render Cart Drawer
  function renderCartDrawer() {
    const container = document.getElementById("cart-items-container");
    const emptyState = document.getElementById("cart-empty-state");
    const footer = document.getElementById("cart-footer");
    const subtotalEl = document.getElementById("cart-subtotal");
    const shippingEl = document.getElementById("cart-shipping");
    const discountEl = document.getElementById("cart-discount");
    const discountRow = document.getElementById("cart-discount-row");
    const totalEl = document.getElementById("cart-total");
    const freeShippingProgress = document.getElementById("free-shipping-progress");
    const freeShippingText = document.getElementById("free-shipping-text");

    if (!container) return;

    if (state.cart.length === 0) {
      container.innerHTML = "";
      emptyState.classList.remove("hidden");
      footer.classList.add("hidden");
      return;
    }

    emptyState.classList.add("hidden");
    footer.classList.remove("hidden");

    let subtotal = 0;
    container.innerHTML = state.cart.map((item, index) => {
      const itemSub = item.price * item.quantity;
      subtotal += itemSub;

      return `
        <div class="flex items-center gap-4 py-4 border-b border-stone-200">
          <img src="${item.image}" alt="${item.name}" class="w-20 h-24 object-cover rounded-sm border border-stone-200">
          <div class="flex-1">
            <h4 class="font-serif text-sm font-semibold text-stone-900 leading-snug">${item.name}</h4>
            <p class="text-xs text-stone-500 mt-1">${item.color} | Size: ${item.size}</p>
            <p class="text-xs font-semibold text-[#c5a059] mt-1">${formatPKR(item.price)}</p>
            
            <div class="flex items-center justify-between mt-3">
              <div class="inline-flex items-center border border-stone-300 rounded-sm">
                <button onclick="window.updateCartQty(${index}, -1)" class="px-2.5 py-0.5 text-xs text-stone-600 hover:bg-stone-100">&minus;</button>
                <span class="px-2.5 py-0.5 text-xs font-medium text-stone-800">${item.quantity}</span>
                <button onclick="window.updateCartQty(${index}, 1)" class="px-2.5 py-0.5 text-xs text-stone-600 hover:bg-stone-100">&plus;</button>
              </div>
              <button onclick="window.removeCartItem(${index})" class="text-xs text-stone-400 hover:text-red-700 transition">
                <i class="fa-regular fa-trash-can mr-1"></i> Remove
              </button>
            </div>
          </div>
        </div>
      `;
    }).join("");

    // Free Shipping threshold (PKR 10,000)
    const threshold = 10000;
    const shipping = subtotal >= threshold || subtotal === 0 ? 0 : 350;
    const progress = Math.min(100, Math.round((subtotal / threshold) * 100));

    if (freeShippingProgress && freeShippingText) {
      freeShippingProgress.style.width = `${progress}%`;
      if (subtotal >= threshold) {
        freeShippingText.innerHTML = `<span class="text-emerald-700 font-semibold"><i class="fa-solid fa-circle-check mr-1"></i> You have unlocked FREE Nationwide Delivery!</span>`;
      } else {
        const remaining = threshold - subtotal;
        freeShippingText.innerHTML = `Add <span class="font-semibold text-stone-900">${formatPKR(remaining)}</span> more to enjoy <strong>Free Shipping</strong>`;
      }
    }

    // Discount
    let discountAmount = 0;
    if (state.promoDiscount > 0) {
      discountAmount = Math.round(subtotal * (state.promoDiscount / 100));
      discountRow.classList.remove("hidden");
      discountEl.textContent = `-${formatPKR(discountAmount)}`;
    } else {
      discountRow.classList.add("hidden");
    }

    const finalTotal = subtotal - discountAmount + shipping;

    subtotalEl.textContent = formatPKR(subtotal);
    shippingEl.textContent = shipping === 0 ? "FREE" : formatPKR(shipping);
    totalEl.textContent = formatPKR(finalTotal);
  }

  window.updateCartQty = function (index, delta) {
    if (!state.cart[index]) return;
    state.cart[index].quantity += delta;
    if (state.cart[index].quantity <= 0) {
      state.cart.splice(index, 1);
    }
    saveCart();
  };

  window.removeCartItem = function (index) {
    if (!state.cart[index]) return;
    const item = state.cart[index];
    state.cart.splice(index, 1);
    saveCart();
    showToast("Item Removed", `${item.name}`);
  };

  // Promo code
  window.applyPromoCode = function () {
    const input = document.getElementById("promo-input");
    const code = input ? input.value.trim().toUpperCase() : "";
    if (code === "ZARI10") {
      state.promoCode = "ZARI10";
      state.promoDiscount = 10;
      showToast("Promo Applied!", "10% VIP Privilege discount activated.");
      renderCartDrawer();
    } else if (code === "BRIDAL20") {
      state.promoCode = "BRIDAL20";
      state.promoDiscount = 20;
      showToast("Bridal Code Applied!", "20% festive couture discount activated.");
      renderCartDrawer();
    } else {
      showToast("Invalid Promo Code", "Try using 'ZARI10' for 10% off.", "wishlist");
    }
  };

  // Product Card HTML generator
  function createProductCardHTML(p) {
    const isWishlisted = state.wishlist.includes(p.id);
    const discountPercent = p.originalPrice ? Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100) : 0;

    return `
      <div class="product-card group relative bg-white border border-stone-200/80 rounded-sm overflow-hidden flex flex-col transition-all duration-300 hover:shadow-xl hover:border-[#c5a059]/40">
        <!-- Badges -->
        <div class="absolute top-3 left-3 z-10 flex flex-col gap-1 pointer-events-none">
          ${p.isNew ? '<span class="px-2 py-0.5 text-[10px] tracking-wider uppercase font-semibold bg-[#4a0e17] text-white">New</span>' : ''}
          ${p.isBestSeller ? '<span class="px-2 py-0.5 text-[10px] tracking-wider uppercase font-semibold bg-[#c5a059] text-stone-900">Bestseller</span>' : ''}
          ${discountPercent > 0 ? `<span class="px-2 py-0.5 text-[10px] tracking-wider uppercase font-semibold bg-emerald-800 text-white">-${discountPercent}%</span>` : ''}
        </div>

        <!-- Wishlist Button -->
        <button 
          data-wishlist-btn="${p.id}"
          onclick="window.toggleWishlist('${p.id}')" 
          class="absolute top-3 right-3 z-10 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md shadow-sm flex items-center justify-center transition hover:scale-110 hover:bg-white"
          title="Wishlist">
          <i class="${isWishlisted ? 'fa-solid fa-heart text-[#c5a059]' : 'fa-regular fa-heart text-stone-600'} text-sm"></i>
        </button>

        <!-- Image Container with Hover Crossfade -->
        <div class="product-card-img-container cursor-pointer" onclick="window.openProductDetailModal('${p.id}')">
          <img src="${p.primaryImage}" alt="${p.name}" class="product-card-img-primary" loading="lazy">
          <img src="${p.secondaryImage || p.primaryImage}" alt="${p.name} detail" class="product-card-img-secondary" loading="lazy">
          
          <!-- Quick View Pill -->
          <div class="absolute inset-x-3 bottom-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <button 
              onclick="event.stopPropagation(); window.openProductDetailModal('${p.id}')" 
              class="w-full py-2.5 px-3 bg-white/95 hover:bg-white text-stone-900 text-xs font-semibold uppercase tracking-wider rounded-sm shadow-md transition flex items-center justify-center gap-1.5">
              <i class="fa-regular fa-eye"></i> Quick View
            </button>
          </div>
        </div>

        <!-- Details -->
        <div class="p-4 flex flex-col flex-1 bg-white">
          <div class="flex items-center justify-between text-xs text-stone-500 mb-1">
            <span class="uppercase tracking-wider text-[11px] font-medium text-[#c5a059]">${p.categoryLabel}</span>
            <div class="flex items-center gap-1 text-amber-500">
              <i class="fa-solid fa-star text-[10px]"></i>
              <span class="text-xs font-medium text-stone-700">${p.rating}</span>
            </div>
          </div>

          <h3 
            onclick="window.openProductDetailModal('${p.id}')" 
            class="font-serif text-base font-medium text-stone-900 group-hover:text-[#4a0e17] transition cursor-pointer line-clamp-1">
            ${p.name}
          </h3>

          <p class="text-xs text-stone-500 mt-1 line-clamp-2">${p.shortDesc}</p>

          <div class="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
            <div>
              <span class="text-sm font-semibold text-stone-900">${formatPKR(p.price)}</span>
              ${p.originalPrice ? `<span class="text-xs text-stone-400 line-through ml-1.5">${formatPKR(p.originalPrice)}</span>` : ''}
            </div>

            <button 
              onclick="window.addToCart('${p.id}')" 
              class="p-2 text-stone-700 hover:text-[#4a0e17] hover:bg-stone-100 rounded-sm transition"
              title="Add to Shopping Bag">
              <i class="fa-solid fa-bag-shopping text-sm"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }

  // Render Product Catalog
  function renderCatalog() {
    const grid = document.getElementById("shop-products-grid");
    const countEl = document.getElementById("shop-results-count");
    if (!grid) return;

    let filtered = window.PRODUCTS_DATA.filter(p => {
      // Category filter
      if (state.activeCategory !== "all" && p.category !== state.activeCategory) {
        return false;
      }
      // Occasion filter
      if (state.filterOccasion !== "all" && !p.occasion.toLowerCase().includes(state.filterOccasion.toLowerCase())) {
        return false;
      }
      // Price filter
      if (p.price > state.filterPriceMax) {
        return false;
      }
      // Search query
      if (state.searchQuery) {
        const query = state.searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(query);
        const matchesDesc = p.description.toLowerCase().includes(query);
        const matchesCat = p.category.toLowerCase().includes(query);
        if (!matchesName && !matchesDesc && !matchesCat) return false;
      }
      return true;
    });

    // Sorting
    if (state.sortBy === "price-low") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (state.sortBy === "price-high") {
      filtered.sort((a, b) => b.price - a.price);
    } else if (state.sortBy === "newest") {
      filtered.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
    } else {
      // Featured / Bestsellers first
      filtered.sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0));
    }

    if (countEl) {
      countEl.textContent = `Showing ${filtered.length} bespoke pieces`;
    }

    if (filtered.length === 0) {
      grid.innerHTML = `
        <div class="col-span-full py-16 text-center">
          <i class="fa-solid fa-compass text-4xl text-stone-300 mb-3"></i>
          <h3 class="font-serif text-lg text-stone-800">No creations found matching your selection</h3>
          <p class="text-xs text-stone-500 max-w-md mx-auto mt-1">Try resetting your occasion filter or expanding your price range to discover other royal heirlooms.</p>
          <button onclick="window.resetShopFilters()" class="mt-4 px-5 py-2 text-xs uppercase tracking-wider font-semibold border border-stone-800 hover:bg-stone-900 hover:text-white transition">Reset All Filters</button>
        </div>
      `;
      return;
    }

    grid.innerHTML = filtered.map(p => createProductCardHTML(p)).join("");
    updateWishlistBadges();
  }

  // Render New Arrivals Carousel / Grid
  function renderNewArrivals() {
    const container = document.getElementById("new-arrivals-grid");
    if (!container) return;

    const newItems = window.PRODUCTS_DATA.filter(p => p.isNew).slice(0, 4);
    container.innerHTML = newItems.map(p => createProductCardHTML(p)).join("");
    updateWishlistBadges();
  }

  // Render Best Sellers
  function renderBestSellers() {
    const container = document.getElementById("bestsellers-grid");
    if (!container) return;

    const bestSellers = window.PRODUCTS_DATA.filter(p => p.isBestSeller).slice(0, 4);
    container.innerHTML = bestSellers.map(p => createProductCardHTML(p)).join("");
    updateWishlistBadges();
  }

  // Render Testimonials
  function renderTestimonials() {
    const container = document.getElementById("testimonials-grid");
    if (!container) return;

    container.innerHTML = window.TESTIMONIALS_DATA.map(t => `
      <div class="bg-white p-6 rounded-sm border border-stone-200/90 shadow-sm flex flex-col justify-between">
        <div>
          <div class="flex text-amber-500 mb-3 text-xs gap-1">
            ${Array(t.rating).fill('<i class="fa-solid fa-star"></i>').join('')}
          </div>
          <p class="font-editorial text-lg text-stone-800 italic leading-relaxed">"${t.comment}"</p>
        </div>
        <div class="mt-6 pt-4 border-t border-stone-100 flex items-center justify-between">
          <div>
            <h4 class="font-serif text-sm font-semibold text-stone-900">${t.name}</h4>
            <p class="text-xs text-stone-500">${t.city}, Pakistan</p>
          </div>
          <span class="text-[10px] tracking-wider uppercase font-semibold px-2 py-0.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded">${t.tag}</span>
        </div>
      </div>
    `).join("");
  }

  // Filter actions
  window.setCategory = function (category) {
    state.activeCategory = category;
    document.querySelectorAll(".category-pill-btn").forEach(btn => {
      const cat = btn.getAttribute("data-category");
      if (cat === category) {
        btn.classList.add("bg-[#4a0e17]", "text-white");
        btn.classList.remove("bg-white", "text-stone-700");
      } else {
        btn.classList.remove("bg-[#4a0e17]", "text-white");
        btn.classList.add("bg-white", "text-stone-700");
      }
    });

    renderCatalog();

    // Scroll smoothly to shop section if triggered from nav
    const shopSection = document.getElementById("shop-section");
    if (shopSection) {
      shopSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  window.setOccasionFilter = function (occ) {
    state.filterOccasion = occ;
    renderCatalog();
  };

  window.setPriceFilter = function (val) {
    state.filterPriceMax = Number(val);
    const display = document.getElementById("price-filter-display");
    if (display) {
      display.textContent = formatPKR(val);
    }
    renderCatalog();
  };

  window.setSortBy = function (sort) {
    state.sortBy = sort;
    renderCatalog();
  };

  window.resetShopFilters = function () {
    state.activeCategory = "all";
    state.filterOccasion = "all";
    state.filterPriceMax = 300000;
    state.sortBy = "featured";
    state.searchQuery = "";

    const priceSlider = document.getElementById("price-range-slider");
    if (priceSlider) priceSlider.value = 300000;
    const priceDisplay = document.getElementById("price-filter-display");
    if (priceDisplay) priceDisplay.textContent = formatPKR(300000);
    const searchInput = document.getElementById("shop-search-input");
    if (searchInput) searchInput.value = "";

    window.setCategory("all");
  };

  // Product Detail Modal
  window.openProductDetailModal = function (productId) {
    const product = window.PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    state.activeProduct = product;
    const modal = document.getElementById("product-detail-modal");
    if (!modal) return;

    let selectedSize = product.sizes ? product.sizes[0] : "Standard";
    let selectedColor = product.color;
    let selectedQty = 1;
    let currentImageIndex = 0;

    const modalContent = document.getElementById("product-modal-content");
    modalContent.innerHTML = `
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 lg:p-8">
        <!-- Left: Image Gallery & Video -->
        <div class="lg:col-span-7 flex flex-col-reverse md:flex-row gap-4">
          <!-- Thumbnail strip -->
          <div class="flex md:flex-col gap-2 overflow-x-auto md:overflow-y-auto max-h-[500px]">
            ${product.gallery.map((img, idx) => `
              <img 
                src="${img}" 
                alt="${product.name} angle ${idx + 1}" 
                onclick="window.switchModalImage(${idx})"
                class="modal-thumb-img w-16 h-20 md:w-20 md:h-24 object-cover cursor-pointer border-2 ${idx === 0 ? 'border-[#c5a059]' : 'border-transparent'} hover:border-[#c5a059]/60 transition rounded-sm">
            `).join("")}
            ${product.hasVideo ? `
              <div 
                onclick="window.showProductVideo('${product.videoUrl}')" 
                class="w-16 h-20 md:w-20 md:h-24 bg-stone-900 text-[#c5a059] flex flex-col items-center justify-center cursor-pointer border-2 border-stone-800 hover:border-[#c5a059] rounded-sm transition">
                <i class="fa-solid fa-play text-lg"></i>
                <span class="text-[9px] uppercase tracking-wider mt-1 font-semibold">Video</span>
              </div>
            ` : ""}
          </div>

          <!-- Main Image with Zoom container -->
          <div class="flex-1 relative aspect-[3/4] bg-stone-100 rounded-sm overflow-hidden zoom-container group">
            <img 
              id="modal-main-image" 
              src="${product.gallery[0]}" 
              alt="${product.name}" 
              class="w-full h-full object-cover">
            
            <div class="absolute top-4 left-4 flex gap-2">
              <span class="px-2.5 py-1 text-xs font-semibold tracking-wider uppercase bg-[#4a0e17] text-white">${product.categoryLabel}</span>
              ${product.isBestSeller ? '<span class="px-2.5 py-1 text-xs font-semibold tracking-wider uppercase bg-[#c5a059] text-stone-900">Bestseller</span>' : ''}
            </div>

            <div class="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded text-[11px] text-stone-700 flex items-center gap-1.5 shadow-sm">
              <i class="fa-solid fa-magnifying-glass-plus"></i> Hover to examine weave
            </div>
          </div>
        </div>

        <!-- Right: Details & Actions -->
        <div class="lg:col-span-5 flex flex-col">
          <div class="flex items-center justify-between text-xs text-stone-500">
            <span>SKU: ${product.sku}</span>
            <div class="flex items-center gap-1 text-amber-500">
              ${Array(5).fill('<i class="fa-solid fa-star text-xs"></i>').join('')}
              <span class="text-xs font-semibold text-stone-800 ml-1">(${product.reviewsCount} reviews)</span>
            </div>
          </div>

          <h2 class="font-serif text-2xl lg:text-3xl text-stone-900 mt-2">${product.name}</h2>
          
          <div class="mt-3 flex items-baseline gap-3">
            <span class="text-2xl font-serif font-bold text-stone-900">${formatPKR(product.price)}</span>
            ${product.originalPrice ? `<span class="text-sm text-stone-400 line-through">${formatPKR(product.originalPrice)}</span>` : ''}
            <span class="text-xs px-2 py-0.5 bg-emerald-50 text-emerald-800 font-semibold border border-emerald-200 rounded">Tax Inclusive</span>
          </div>

          <p class="text-xs text-stone-500 mt-2 flex items-center gap-2">
            <i class="fa-solid fa-truck-fast text-[#c5a059]"></i> Free nationwide doorstep delivery on this piece
          </p>

          <p class="text-sm text-stone-600 mt-4 leading-relaxed">${product.description}</p>

          <!-- Color Swatch -->
          <div class="mt-6">
            <label class="block text-xs font-semibold uppercase tracking-wider text-stone-800 mb-2">
              Color: <span class="font-normal text-stone-600">${product.color}</span>
            </label>
            <div class="flex items-center gap-3">
              <div class="w-7 h-7 rounded-full border-2 border-[#c5a059] p-0.5 shadow-sm">
                <div class="w-full h-full rounded-full" style="background-color: ${product.colorHex};"></div>
              </div>
            </div>
          </div>

          <!-- Size Selector -->
          ${product.sizes && product.sizes.length > 0 ? `
            <div class="mt-5">
              <div class="flex items-center justify-between mb-2">
                <label class="text-xs font-semibold uppercase tracking-wider text-stone-800">Select Size</label>
                <button onclick="window.openSizeGuideModal()" class="text-xs text-[#c5a059] hover:underline font-medium">
                  <i class="fa-solid fa-ruler-combined mr-1"></i> Size Guide
                </button>
              </div>
              <div class="flex flex-wrap gap-2" id="modal-size-container">
                ${product.sizes.map((s, idx) => `
                  <button 
                    type="button" 
                    onclick="window.selectModalSize('${s}', this)" 
                    class="modal-size-btn px-4 py-2 text-xs font-semibold border ${idx === 0 ? 'border-[#4a0e17] bg-[#4a0e17] text-white' : 'border-stone-300 text-stone-700 hover:border-stone-400'} rounded-sm transition">
                    ${s}
                  </button>
                `).join("")}
              </div>
            </div>
          ` : ""}

          <!-- Quantity Stepper -->
          <div class="mt-6 flex items-center gap-4">
            <label class="text-xs font-semibold uppercase tracking-wider text-stone-800">Quantity</label>
            <div class="inline-flex items-center border border-stone-300 rounded-sm">
              <button onclick="window.changeModalQty(-1)" class="px-3 py-1.5 text-stone-600 hover:bg-stone-100">&minus;</button>
              <span id="modal-qty-display" class="px-4 py-1.5 text-sm font-semibold text-stone-900">1</span>
              <button onclick="window.changeModalQty(1)" class="px-3 py-1.5 text-stone-600 hover:bg-stone-100">&plus;</button>
            </div>
          </div>

          <!-- Actions -->
          <div class="mt-6 flex flex-col sm:flex-row gap-3">
            <button 
              id="modal-add-cart-btn"
              onclick="window.modalAddToCart(false)" 
              class="flex-1 py-3.5 px-6 border border-[#4a0e17] text-[#4a0e17] hover:bg-[#4a0e17] hover:text-white text-xs font-semibold uppercase tracking-widest transition rounded-sm flex items-center justify-center gap-2">
              <i class="fa-solid fa-bag-shopping"></i> Add to Bag
            </button>
            
            <button 
              id="modal-buy-now-btn"
              onclick="window.modalAddToCart(true)" 
              class="flex-1 py-3.5 px-6 btn-gold-shimmer text-xs font-bold uppercase tracking-widest rounded-sm flex items-center justify-center gap-2">
              Buy Now
            </button>

            <button 
              onclick="window.toggleWishlist('${product.id}')" 
              class="p-3.5 border border-stone-300 text-stone-700 hover:text-[#c5a059] hover:border-[#c5a059] rounded-sm transition flex items-center justify-center"
              title="Add to Wishlist">
              <i class="${state.wishlist.includes(product.id) ? 'fa-solid fa-heart text-[#c5a059]' : 'fa-regular fa-heart'} text-base"></i>
            </button>
          </div>

          <!-- WhatsApp Direct Inquiry -->
          <a 
            href="https://wa.me/923001234567?text=${encodeURIComponent(`Hello Zari & Zawer, I would like to inquire about the ${product.name} (SKU: ${product.sku}, ${formatPKR(product.price)}).`)}" 
            target="_blank" 
            class="mt-3 py-2.5 px-4 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-semibold rounded-sm transition flex items-center justify-center gap-2">
            <i class="fa-brands fa-whatsapp text-emerald-600 text-base"></i> Inquire via WhatsApp Concierge
          </a>

          <!-- Accordion details -->
          <div class="mt-8 border-t border-stone-200 divide-y divide-stone-200">
            <details class="py-3 text-xs group" open>
              <summary class="font-semibold uppercase tracking-wider text-stone-800 flex justify-between items-center cursor-pointer list-none">
                <span>Fabric & Craftsmanship</span>
                <i class="fa-solid fa-chevron-down text-stone-400 group-open:rotate-180 transition-transform"></i>
              </summary>
              <p class="mt-2 text-stone-600 leading-relaxed">${product.fabric}</p>
            </details>
            
            <details class="py-3 text-xs group">
              <summary class="font-semibold uppercase tracking-wider text-stone-800 flex justify-between items-center cursor-pointer list-none">
                <span>Delivery Timelines & COD</span>
                <i class="fa-solid fa-chevron-down text-stone-400 group-open:rotate-180 transition-transform"></i>
              </summary>
              <div class="mt-2 text-stone-600 space-y-1">
                <p>• Ready to ship pieces dispatched within 24-48 business hours.</p>
                <p>• Bespoke custom stitching takes 14-21 business days.</p>
                <p>• Cash on Delivery (COD) available nationwide.</p>
              </div>
            </details>

            <details class="py-3 text-xs group">
              <summary class="font-semibold uppercase tracking-wider text-stone-800 flex justify-between items-center cursor-pointer list-none">
                <span>Return & Exchange Policy</span>
                <i class="fa-solid fa-chevron-down text-stone-400 group-open:rotate-180 transition-transform"></i>
              </summary>
              <p class="mt-2 text-stone-600 leading-relaxed">
                We offer a hassle-free 7-day exchange window for pret pieces and jewelry sets. Custom bridal orders are handcrafted to your exact body measurements and cannot be returned.
              </p>
            </details>
          </div>
        </div>
      </div>

      <!-- You May Also Like -->
      <div class="border-t border-stone-200 p-6 lg:p-8 bg-stone-50/50">
        <h4 class="font-serif text-lg text-stone-900 mb-4">You May Also Admire</h4>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          ${window.PRODUCTS_DATA
            .filter(p => p.id !== product.id && p.category === product.category)
            .slice(0, 4)
            .map(p => `
              <div class="cursor-pointer group" onclick="window.openProductDetailModal('${p.id}')">
                <div class="aspect-[3/4] overflow-hidden rounded-sm bg-white border border-stone-200">
                  <img src="${p.primaryImage}" alt="${p.name}" class="w-full h-full object-cover group-hover:scale-105 transition duration-500">
                </div>
                <h5 class="font-serif text-xs font-semibold text-stone-900 mt-2 truncate group-hover:text-[#4a0e17]">${p.name}</h5>
                <p class="text-xs text-[#c5a059] font-medium">${formatPKR(p.price)}</p>
              </div>
            `).join("")}
        </div>
      </div>
    `;

    // Zoom setup
    const mainImg = modalContent.querySelector("#modal-main-image");
    const zoomContainer = modalContent.querySelector(".zoom-container");
    if (zoomContainer && mainImg) {
      zoomContainer.addEventListener("mousemove", (e) => {
        const rect = zoomContainer.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;
        mainImg.style.transformOrigin = `${x}% ${y}%`;
        mainImg.style.transform = "scale(1.75)";
      });
      zoomContainer.addEventListener("mouseleave", () => {
        mainImg.style.transform = "scale(1)";
        mainImg.style.transformOrigin = "center center";
      });
    }

    modal.classList.add("active");
    document.body.style.overflow = "hidden";

    // Internal Modal state handlers
    window._modalSelectedSize = selectedSize;
    window._modalSelectedQty = 1;
  };

  window.closeProductDetailModal = function () {
    const modal = document.getElementById("product-detail-modal");
    if (!modal) return;
    modal.classList.remove("active");
    document.body.style.overflow = "";
  };

  window.switchModalImage = function (index) {
    if (!state.activeProduct || !state.activeProduct.gallery[index]) return;
    const mainImg = document.getElementById("modal-main-image");
    if (mainImg) {
      mainImg.src = state.activeProduct.gallery[index];
    }
    document.querySelectorAll(".modal-thumb-img").forEach((img, i) => {
      img.classList.toggle("border-[#c5a059]", i === index);
      img.classList.toggle("border-transparent", i !== index);
    });
  };

  window.selectModalSize = function (size, btn) {
    window._modalSelectedSize = size;
    document.querySelectorAll(".modal-size-btn").forEach(b => {
      b.classList.remove("border-[#4a0e17]", "bg-[#4a0e17]", "text-white");
      b.classList.add("border-stone-300", "text-stone-700");
    });
    btn.classList.add("border-[#4a0e17]", "bg-[#4a0e17]", "text-white");
    btn.classList.remove("border-stone-300", "text-stone-700");
  };

  window.changeModalQty = function (delta) {
    let qty = (window._modalSelectedQty || 1) + delta;
    if (qty < 1) qty = 1;
    if (qty > 10) qty = 10;
    window._modalSelectedQty = qty;
    const display = document.getElementById("modal-qty-display");
    if (display) display.textContent = qty;
  };

  window.modalAddToCart = function (buyNow = false) {
    if (!state.activeProduct) return;
    const size = window._modalSelectedSize || (state.activeProduct.sizes ? state.activeProduct.sizes[0] : "Standard");
    const qty = window._modalSelectedQty || 1;

    window.addToCart(state.activeProduct.id, size, state.activeProduct.color, qty, !buyNow);
    window.closeProductDetailModal();

    if (buyNow) {
      window.openCheckoutModal();
    }
  };

  // Video Preview Modal
  window.showProductVideo = function (videoUrl) {
    const modal = document.getElementById("generic-modal");
    const title = document.getElementById("generic-modal-title");
    const body = document.getElementById("generic-modal-body");
    if (!modal) return;

    title.textContent = "Artisanal Video Preview";
    body.innerHTML = `
      <div class="aspect-video bg-black rounded overflow-hidden">
        <video controls autoplay loop class="w-full h-full object-cover">
          <source src="${videoUrl}" type="video/mp4">
          Your browser does not support video playback.
        </video>
      </div>
    `;
    modal.classList.add("active");
  };

  // Wishlist Modal
  window.openWishlistModal = function () {
    const modal = document.getElementById("generic-modal");
    const title = document.getElementById("generic-modal-title");
    const body = document.getElementById("generic-modal-body");
    if (!modal) return;

    title.textContent = "Your Curated Wishlist";

    if (state.wishlist.length === 0) {
      body.innerHTML = `
        <div class="text-center py-12">
          <i class="fa-regular fa-heart text-4xl text-stone-300 mb-3"></i>
          <h4 class="font-serif text-lg text-stone-800">Your wishlist is currently empty</h4>
          <p class="text-xs text-stone-500 max-w-sm mx-auto mt-1">Explore our couture dresses, kundan jewelry, and crystal minaudières to bookmark your favorites.</p>
          <button onclick="window.closeGenericModal(); window.setCategory('all');" class="mt-4 px-6 py-2.5 bg-[#4a0e17] text-white text-xs uppercase tracking-wider font-semibold rounded-sm">Explore Collection</button>
        </div>
      `;
    } else {
      const items = window.PRODUCTS_DATA.filter(p => state.wishlist.includes(p.id));
      body.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto pr-1">
          ${items.map(p => `
            <div class="flex items-center gap-3 p-3 border border-stone-200 rounded-sm bg-white">
              <img src="${p.primaryImage}" alt="${p.name}" class="w-16 h-20 object-cover rounded-sm">
              <div class="flex-1">
                <h5 class="font-serif text-xs font-semibold text-stone-900">${p.name}</h5>
                <p class="text-xs text-[#c5a059] font-medium mt-0.5">${formatPKR(p.price)}</p>
                <div class="flex gap-2 mt-2">
                  <button onclick="window.addToCart('${p.id}'); window.closeGenericModal();" class="px-2.5 py-1 text-[11px] bg-[#4a0e17] text-white rounded-sm font-medium">Add to Bag</button>
                  <button onclick="window.toggleWishlist('${p.id}'); window.openWishlistModal();" class="text-stone-400 hover:text-red-700 text-xs"><i class="fa-solid fa-trash-can"></i></button>
                </div>
              </div>
            </div>
          `).join("")}
        </div>
      `;
    }

    modal.classList.add("active");
  };

  // Checkout Modal
  window.openCheckoutModal = function () {
    window.closeCartDrawer();
    const modal = document.getElementById("checkout-modal");
    if (!modal) return;

    if (state.cart.length === 0) {
      showToast("Shopping Bag Empty", "Please select an item before proceeding to checkout.", "wishlist");
      return;
    }

    // Populate checkout order summary
    const checkoutSummaryEl = document.getElementById("checkout-items-summary");
    const checkoutSubtotalEl = document.getElementById("checkout-subtotal");
    const checkoutShippingEl = document.getElementById("checkout-shipping");
    const checkoutDiscountEl = document.getElementById("checkout-discount");
    const checkoutDiscountRow = document.getElementById("checkout-discount-row");
    const checkoutTotalEl = document.getElementById("checkout-total");

    let subtotal = 0;
    checkoutSummaryEl.innerHTML = state.cart.map(item => {
      const line = item.price * item.quantity;
      subtotal += line;
      return `
        <div class="flex items-center justify-between text-xs py-2 border-b border-stone-100">
          <div class="flex items-center gap-2">
            <span class="w-5 h-5 rounded-full bg-stone-200 text-stone-800 text-[10px] font-bold flex items-center justify-center">${item.quantity}</span>
            <div>
              <p class="font-medium text-stone-800">${item.name}</p>
              <p class="text-[10px] text-stone-400">${item.color} | ${item.size}</p>
            </div>
          </div>
          <span class="font-semibold text-stone-800">${formatPKR(line)}</span>
        </div>
      `;
    }).join("");

    const threshold = 10000;
    const shipping = subtotal >= threshold ? 0 : 350;
    let discountAmount = 0;
    if (state.promoDiscount > 0) {
      discountAmount = Math.round(subtotal * (state.promoDiscount / 100));
      checkoutDiscountRow.classList.remove("hidden");
      checkoutDiscountEl.textContent = `-${formatPKR(discountAmount)}`;
    } else {
      checkoutDiscountRow.classList.add("hidden");
    }

    const total = subtotal - discountAmount + shipping;

    checkoutSubtotalEl.textContent = formatPKR(subtotal);
    checkoutShippingEl.textContent = shipping === 0 ? "FREE" : formatPKR(shipping);
    checkoutTotalEl.textContent = formatPKR(total);

    modal.classList.add("active");
    document.body.style.overflow = "hidden";
  };

  window.closeCheckoutModal = function () {
    const modal = document.getElementById("checkout-modal");
    if (!modal) return;
    modal.classList.remove("active");
    document.body.style.overflow = "";
  };

  // Submit Order
  window.submitOrder = function (e) {
    e.preventDefault();
    const form = document.getElementById("checkout-form");
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    const name = document.getElementById("cust-name").value;
    const phone = document.getElementById("cust-phone").value;
    const city = document.getElementById("cust-city").value;
    const address = document.getElementById("cust-address").value;
    const payment = document.querySelector('input[name="payment_method"]:checked')?.value || "Cash on Delivery";

    const orderNumber = "ZZ-" + Math.floor(100000 + Math.random() * 900000);
    const subtotal = state.cart.reduce((s, i) => s + (i.price * i.quantity), 0);
    const threshold = 10000;
    const shipping = subtotal >= threshold ? 0 : 350;
    const discount = state.promoDiscount > 0 ? Math.round(subtotal * (state.promoDiscount / 100)) : 0;
    const grandTotal = subtotal - discount + shipping;

    // Show order success receipt
    const checkoutBody = document.getElementById("checkout-modal-body");
    checkoutBody.innerHTML = `
      <div class="text-center py-8 px-4">
        <div class="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl shadow-sm">
          <i class="fa-solid fa-check"></i>
        </div>
        <span class="text-xs font-semibold tracking-widest uppercase text-[#c5a059]">Order Confirmed</span>
        <h3 class="font-serif text-2xl text-stone-900 mt-1">Shukriya, ${name}!</h3>
        <p class="text-xs text-stone-500 mt-1">Your royal order <strong class="text-stone-800">#${orderNumber}</strong> has been registered with our atelier.</p>

        <div class="mt-6 bg-stone-50 border border-stone-200 rounded p-4 text-left text-xs space-y-2">
          <div class="flex justify-between">
            <span class="text-stone-500">Destination:</span>
            <span class="font-medium text-stone-800">${address}, ${city}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-stone-500">Contact:</span>
            <span class="font-medium text-stone-800">${phone}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-stone-500">Payment Mode:</span>
            <span class="font-medium text-stone-800">${payment}</span>
          </div>
          <div class="flex justify-between font-bold text-stone-900 pt-2 border-t border-stone-200">
            <span>Total Payable:</span>
            <span class="text-[#4a0e17]">${formatPKR(grandTotal)}</span>
          </div>
        </div>

        <p class="text-[11px] text-stone-500 mt-4 leading-relaxed">
          A confirmation SMS & WhatsApp invoice has been dispatched to your mobile. Our courier partner will contact you prior to delivery.
        </p>

        <div class="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
          <a 
            href="https://wa.me/923001234567?text=${encodeURIComponent(`Hello Zari & Zawer, I just placed order #${orderNumber} for ${formatPKR(grandTotal)}. Name: ${name}, City: ${city}. Please confirm my shipment details.`)}" 
            target="_blank" 
            class="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold uppercase tracking-wider rounded-sm transition flex items-center justify-center gap-2">
            <i class="fa-brands fa-whatsapp text-sm"></i> Track on WhatsApp
          </a>

          <button 
            onclick="window.finishCheckout()" 
            class="px-5 py-3 bg-[#4a0e17] text-white text-xs font-semibold uppercase tracking-wider rounded-sm hover:bg-[#35070e] transition">
            Continue Shopping
          </button>
        </div>
      </div>
    `;

    // Empty cart
    state.cart = [];
    state.promoDiscount = 0;
    state.promoCode = null;
    saveCart();
  };

  window.finishCheckout = function () {
    window.closeCheckoutModal();
    window.location.reload();
  };

  // Generic Modal open/close
  window.closeGenericModal = function () {
    const modal = document.getElementById("generic-modal");
    if (!modal) return;
    modal.classList.remove("active");
  };

  // Size Guide Modal
  window.openSizeGuideModal = function () {
    const modal = document.getElementById("generic-modal");
    const title = document.getElementById("generic-modal-title");
    const body = document.getElementById("generic-modal-body");
    if (!modal) return;

    title.textContent = "Atelier Size & Measurement Guide";
    body.innerHTML = `
      <div class="text-xs text-stone-600">
        <p class="mb-3">All measurements are provided in inches. For custom bespoke bridal sizing, our master karigar offers virtual video consultations.</p>
        <div class="overflow-x-auto">
          <table class="w-full border-collapse border border-stone-200 text-left">
            <thead>
              <tr class="bg-stone-100 text-stone-900 font-semibold">
                <th class="p-2 border border-stone-200">Size</th>
                <th class="p-2 border border-stone-200">Bust</th>
                <th class="p-2 border border-stone-200">Waist</th>
                <th class="p-2 border border-stone-200">Hips</th>
                <th class="p-2 border border-stone-200">Kurti Length</th>
              </tr>
            </thead>
            <tbody>
              <tr><td class="p-2 border border-stone-200 font-semibold">XS</td><td class="p-2 border border-stone-200">34"</td><td class="p-2 border border-stone-200">28"</td><td class="p-2 border border-stone-200">37"</td><td class="p-2 border border-stone-200">46"</td></tr>
              <tr class="bg-stone-50"><td class="p-2 border border-stone-200 font-semibold">S</td><td class="p-2 border border-stone-200">36"</td><td class="p-2 border border-stone-200">30"</td><td class="p-2 border border-stone-200">39"</td><td class="p-2 border border-stone-200">47"</td></tr>
              <tr><td class="p-2 border border-stone-200 font-semibold">M</td><td class="p-2 border border-stone-200">39"</td><td class="p-2 border border-stone-200">33"</td><td class="p-2 border border-stone-200">42"</td><td class="p-2 border border-stone-200">48"</td></tr>
              <tr class="bg-stone-50"><td class="p-2 border border-stone-200 font-semibold">L</td><td class="p-2 border border-stone-200">42"</td><td class="p-2 border border-stone-200">36"</td><td class="p-2 border border-stone-200">45"</td><td class="p-2 border border-stone-200">48"</td></tr>
              <tr><td class="p-2 border border-stone-200 font-semibold">XL</td><td class="p-2 border border-stone-200">45"</td><td class="p-2 border border-stone-200">39"</td><td class="p-2 border border-stone-200">48"</td><td class="p-2 border border-stone-200">49"</td></tr>
              <tr class="bg-amber-50/50"><td class="p-2 border border-stone-200 font-bold text-[#4a0e17]">Custom</td><td colspan="4" class="p-2 border border-stone-200 italic">Tailored to your exact measurements at no extra cost</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
    modal.classList.add("active");
  };

  // Live Search
  window.handleSearchInput = function (val) {
    state.searchQuery = val.trim();
    renderCatalog();
  };

  // Mobile menu toggle
  window.toggleMobileMenu = function () {
    const menu = document.getElementById("mobile-menu-drawer");
    if (menu) {
      menu.classList.toggle("hidden");
    }
  };

  // Setup DOM Listeners once loaded
  document.addEventListener("DOMContentLoaded", () => {
    updateCounters();
    renderNewArrivals();
    renderBestSellers();
    renderCatalog();
    renderTestimonials();

    // Setup search listener
    const searchInput = document.getElementById("shop-search-input");
    if (searchInput) {
      searchInput.addEventListener("input", (e) => window.handleSearchInput(e.target.value));
    }

    // Nav search input
    const navSearch = document.getElementById("nav-search-input");
    if (navSearch) {
      navSearch.addEventListener("keyup", (e) => {
        if (e.key === "Enter") {
          window.handleSearchInput(e.target.value);
          const shopSection = document.getElementById("shop-section");
          if (shopSection) shopSection.scrollIntoView({ behavior: "smooth" });
        }
      });
    }

    // Close drawers when clicking backdrops
    const cartBackdrop = document.getElementById("cart-drawer-backdrop");
    if (cartBackdrop) {
      cartBackdrop.addEventListener("click", window.closeCartDrawer);
    }

    const detailModal = document.getElementById("product-detail-modal");
    if (detailModal) {
      detailModal.addEventListener("click", (e) => {
        if (e.target === detailModal) window.closeProductDetailModal();
      });
    }

    const checkoutModal = document.getElementById("checkout-modal");
    if (checkoutModal) {
      checkoutModal.addEventListener("click", (e) => {
        if (e.target === checkoutModal) window.closeCheckoutModal();
      });
    }

    const genericModal = document.getElementById("generic-modal");
    if (genericModal) {
      genericModal.addEventListener("click", (e) => {
        if (e.target === genericModal) window.closeGenericModal();
      });
    }

    // Escape key listener for modals
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        window.closeCartDrawer();
        window.closeProductDetailModal();
        window.closeCheckoutModal();
        window.closeGenericModal();
      }
    });
  });

})();
